# Team Pony EÜR – Android APK wrapper

Diese Android-App öffnet die Live-Web-App:
https://phenomenal-sfogliatella-09cbcb.netlify.app/

Dadurch erscheinen spätere Änderungen an der Netlify-App automatisch auch in der installierten Android-App, ohne für jede Web-Änderung eine neue APK zu benötigen.

Enthalten:
- App-Name: Team Pony EÜR
- Paket: de.teampony.euer
- Belegauswahl aus Dateien/PDF
- Kameraauswahl für Belegfotos
- JavaScript / LocalStorage / Cookies für die Web-App
- Zurück-Taste navigiert innerhalb der App
- GitHub Action erzeugt eine installierbare Debug-APK

## APK über GitHub erzeugen
1. Projekt in ein GitHub-Repository hochladen.
2. Unter Actions den Workflow "Build Team Pony APK" starten (oder einfach auf main pushen).
3. Nach erfolgreichem Lauf das Artefakt "Team-Pony-EUER-APK" herunterladen.
4. `Team-Pony-EUER.apk` auf dem Android-Handy öffnen und installieren.

Hinweis: Android kann beim ersten manuellen APK-Installieren fragen, ob die Installation aus dieser Quelle erlaubt werden soll.


Version 1.1: Android-Randwischgeste und Zurück-Navigation für die Team-Pony-Web-App ergänzt.

Version 1.2: Hoch- und Querformat freigegeben; Android-Randwischgeste bleibt aktiv.
